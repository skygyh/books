gs_channels="NONE";
